document.addEventListener("DOMContentLoaded", () => {
    let allPosts = [];
    let displayedCount = 5;
    let postToDeleteId = null;

    const postsContainer = document.getElementById("postsContainer");
    const loadMoreSection = document.getElementById("loadMoreSection");
    const createPostPopup = document.getElementById("createPostPopup");
    const deletePostPopup = document.getElementById("deletePostPopup");
    const navProfileAvatar = document.getElementById("navProfileAvatar");

    // Ambil Data Postingan dari Server saat load
    async function fetchPosts() {
        try {
            const response = await fetch('/api/community/posts');
            const data = await response.json();
            if (data.success) {
                allPosts = data.posts;
                renderPosts();
                updateNavbarAvatar();
            }
        } catch (err) {
            console.error("Gagal memuat forum data.", err);
        }
    }

    function updateNavbarAvatar() {
        if (allPosts.length > 0 && allPosts[0].author) {
            const naelUser = allPosts.find(p => p.username === "nael123");
            if (naelUser) {
                navProfileAvatar.src = naelUser.author.profilePic;
            }
        }
    }

    function renderPosts() {
        postsContainer.innerHTML = "";
        const currentSlice = allPosts.slice(0, displayedCount);

        if (currentSlice.length === 0) {
            postsContainer.innerHTML = `<p style="color:var(--text-muted); text-align:center; margin-top:20px;">Belum ada postingan komunitas.</p>`;
            loadMoreSection.style.display = "none";
            return;
        }

        currentSlice.forEach(post => {
            const card = document.createElement("div");
            card.className = "post-card";

            const dateStr = new Date(post.date).toLocaleDateString('id-ID', { day: 'numeric', month: 'short', year: 'numeric' });

            const maxLength = 120;
            let descriptionHTML = "";
            if (post.description.length > maxLength) {
                const shortText = post.description.substring(0, maxLength);
                descriptionHTML = `
                    <span class="text-short">${shortText}... <span class="read-more-btn">Baca selengkapnya..</span></span>
                    <span class="text-full" style="display:none;">${post.description}</span>
                `;
            } else {
                descriptionHTML = `<span>${post.description}</span>`;
            }

            let mediaHTML = "";
            if (post.media) {
                if (post.mediaType === "video") {
                    mediaHTML = `<video src="${post.media}" controls class="post-media"></video>`;
                } else {
                    mediaHTML = `<img src="${post.media}" alt="Post Media" class="post-media">`;
                }
            }

            card.innerHTML = `
                <div class="post-author-row">
                    <img src="${post.author.profilePic}" alt="Ava" class="author-img">
                    <div>
                        <div class="author-name">${post.author.displayname}</div>
                        <div class="author-username">@${post.author.username}</div>
                    </div>
                    <div class="post-date">${dateStr}</div>
                </div>
                <h4 class="post-title">${post.title}</h4>
                <div class="post-desc" id="desc_${post.id}">${descriptionHTML}</div>
                ${mediaHTML}
                <div class="post-actions">
                    <button class="action-item" id="like_${post.id}">
                        <span>👍</span> <span class="like-count">${post.likes}</span>
                    </button>
                    <button class="action-item" style="margin-left:auto; color:#ef4444;" id="del_${post.id}">
                        Hapus
                    </button>
                </div>
            `;

            postsContainer.appendChild(card);

            const descBlock = card.querySelector(`#desc_${post.id}`);
            descBlock.addEventListener("click", () => {
                const shortSpan = descBlock.querySelector(".text-short");
                const fullSpan = descBlock.querySelector(".text-full");
                if (shortSpan && fullSpan && fullSpan.style.display === "none") {
                    shortSpan.style.display = "none";
                    fullSpan.style.display = "inline";
                }
            });

            const likeBtn = card.querySelector(`#like_${post.id}`);
            likeBtn.addEventListener("click", async () => {
                const cooldownKey = `like_cd_${post.id}`;
                const lastLiked = localStorage.getItem(cooldownKey);
                const now = Date.now();

                if (lastLiked && (now - lastLiked < 20 * 60 * 1000)) {
                    const minutesLeft = Math.ceil((20 * 60 * 1000 - (now - lastLiked)) / 60 / 1000);
                    alert(`Kamu baru saja menyukai ini. Tunggu ${minutesLeft} menit lagi.`);
                    return;
                }

                try {
                    const res = await fetch('/api/community/posts/like', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ postId: post.id })
                    });
                    const resData = await res.json();
                    if (resData.success) {
                        likeBtn.querySelector(".like-count").textContent = resData.likes;
                        localStorage.setItem(cooldownKey, now);
                    }
                } catch (e) { console.error(e); }
            });

            card.querySelector(`#del_${post.id}`).addEventListener("click", () => {
                postToDeleteId = post.id;
                document.getElementById("deleteError").style.display = "none";
                document.getElementById("deleteAuthUser").value = "";
                document.getElementById("deleteAuthPass").value = "";
                deletePostPopup.classList.add("active");
            });
        });

        if (allPosts.length > displayedCount) {
            loadMoreSection.style.display = "block";
        } else {
            loadMoreSection.style.display = "none";
        }
    }

    document.getElementById("btnLoadMore").addEventListener("click", () => {
        displayedCount += 5;
        renderPosts();
    });

    // TRIGGER POPUP BUAT POST + CEK COOLDOWN 10 MENIT
    document.getElementById("btnCreatePost").addEventListener("click", () => {
        const lastPosted = localStorage.getItem("last_post_time");
        const now = Date.now();
        const cooldownTime = 10 * 60 * 1000; // 10 menit dalam milidetik

        if (lastPosted && (now - lastPosted < cooldownTime)) {
            const timeDiff = cooldownTime - (now - lastPosted);
            const minutesLeft = Math.floor(timeDiff / 60 / 1000);
            const secondsLeft = Math.floor((timeDiff % (60 * 1000)) / 1000);
            
            alert(`Sistem Mendeteksi Spam! Silakan tunggu ${minutesLeft} menit ${secondsLeft} detik lagi sebelum mengirim postingan baru.`);
            return;
        }

        document.getElementById("createError").style.display = "none";
        createPostPopup.classList.add("active");
    });
    
    document.getElementById("btnCancelCreate").addEventListener("click", () => createPostPopup.classList.remove("active"));
    document.getElementById("btnCancelDelete").addEventListener("click", () => deletePostPopup.classList.remove("active"));

    // SUBMIT POST BARU
    document.getElementById("btnSubmitPost").addEventListener("click", async () => {
        const title = document.getElementById("postTitleInput").value;
        const description = document.getElementById("postDescInput").value;
        const media = document.getElementById("postMediaInput").value;
        const username = document.getElementById("postAuthUser").value;
        const password = document.getElementById("postAuthPass").value;
        const createError = document.getElementById("createError");

        if (!title || !description || !username || !password) {
            createError.style.display = "block";
            createError.textContent = "Kolom Judul, Deskripsi, Username & Password wajib terisi!";
            return;
        }

        try {
            const response = await fetch('/api/community/posts/create', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ username, password, title, description, media })
            });
            const data = await response.json();

            if (data.success) {
                // CATAT TIMESTAMP BERHASIL POSTING KE LOCALSTORAGE
                localStorage.setItem("last_post_time", Date.now());

                createPostPopup.classList.remove("active");
                document.getElementById("postTitleInput").value = "";
                document.getElementById("postDescInput").value = "";
                document.getElementById("postMediaInput").value = "";
                document.getElementById("postAuthUser").value = "";
                document.getElementById("postAuthPass").value = "";
                fetchPosts();
            } else {
                createError.style.display = "block";
                createError.textContent = data.message;
            }
        } catch (err) {
            createError.style.display = "block";
            createError.textContent = "Gagal memproses request pembuatan.";
        }
    });

    // EKSEKUSI HAPUS
    document.getElementById("btnSubmitDelete").addEventListener("click", async () => {
        const username = document.getElementById("deleteAuthUser").value;
        const password = document.getElementById("deleteAuthPass").value;
        const deleteError = document.getElementById("deleteError");

        try {
            const response = await fetch('/api/community/posts/delete', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ postId: postToDeleteId, username, password })
            });
            const data = await response.json();

            if (data.success) {
                deletePostPopup.classList.remove("active");
                fetchPosts();
            } else {
                deleteError.style.display = "block";
                deleteError.textContent = data.message;
            }
        } catch (err) {
            deleteError.style.display = "block";
            deleteError.textContent = "Gagal memproses request penghapusan.";
        }
    });

    fetchPosts();
});
