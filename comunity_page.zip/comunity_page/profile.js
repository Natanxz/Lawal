document.addEventListener("DOMContentLoaded", () => {
    let sessionUser = null; // Menyimpan data user sementara di memori halaman
    let currentEditField = ""; // Melacak kolom apa yang sedang diedit (avatar, nick, atau user)

    const loginPopup = document.getElementById("loginPopup");
    const editPopup = document.getElementById("editPopup");
    const profileView = document.getElementById("profileView");

    // Munculkan popup login otomatis di awal
    setTimeout(() => loginPopup.classList.add("active"), 200);

    // Proses login / cari data user
    document.getElementById("btnSubmitLogin").addEventListener("click", async () => {
        const username = document.getElementById("loginUser").value;
        const password = document.getElementById("loginPass").value;
        const loginError = document.getElementById("loginError");

        try {
            const response = await fetch('/api/community/login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ username, password })
            });
            const data = await response.json();

            if (data.success) {
                sessionUser = data.user; // Simpan data user yang berhasil login
                renderProfile();
                loginPopup.classList.remove("active");
                profileView.style.display = "block";
            } else {
                loginError.style.display = "block";
                loginError.textContent = data.message;
            }
        } catch (err) {
            loginError.style.display = "block";
            loginError.textContent = "Error menghubungi server.";
        }
    });

    function renderProfile() {
        document.getElementById("displayAvatar").src = sessionUser.profilePic;
        document.getElementById("displayNick").textContent = sessionUser.displayname;
        document.getElementById("displayUser").textContent = sessionUser.username;
    }

    // Pemetaan Trigger Tombol Edit
    document.getElementById("btnEditAvatar").addEventListener("click", () => openEditBox("avatar", "EDIT FOTO URL", sessionUser.profilePic));
    document.getElementById("btnEditNick").addEventListener("click", () => openEditBox("nick", "EDIT DISPLAY NAME", sessionUser.displayname));
    document.getElementById("btnEditUser").addEventListener("click", () => openEditBox("user", "EDIT USERNAME", sessionUser.username));

    function openEditBox(field, title, currentVal) {
        currentEditField = field;
        document.getElementById("editTitle").textContent = title;
        document.getElementById("editNewValue").value = currentVal;
        document.getElementById("editError").style.display = "none";
        // Reset kolom konfirmasi wajib isi
        document.getElementById("confirmUser").value = "";
        document.getElementById("confirmPass").value = "";
        editPopup.classList.add("active");
    }

    document.getElementById("btnCancelEdit").addEventListener("click", () => editPopup.classList.remove("active"));

    // Simpan data hasil editan dengan konfirmasi wajib username lama & password
    document.getElementById("btnSaveEdit").addEventListener("click", async () => {
        const newValue = document.getElementById("editNewValue").value;
        const confirmUser = document.getElementById("confirmUser").value;
        const confirmPass = document.getElementById("confirmPass").value;
        const editError = document.getElementById("editError");

        if (confirmUser.toLowerCase() !== sessionUser.username.toLowerCase()) {
            editError.style.display = "block";
            editError.textContent = "Username sebelumnya tidak cocok!";
            return;
        }

        // Susun payload body data dinamis sesuai kolom yang dituju
        let payload = {
            currentUsername: sessionUser.username,
            password: confirmPass
        };

        if (currentEditField === "avatar") payload.newProfilePic = newValue;
        if (currentEditField === "nick") payload.newDisplayName = newValue;
        if (currentEditField === "user") payload.newUsername = newValue;

        try {
            const response = await fetch('/api/community/profile/update', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });
            const data = await response.json();

            if (data.success) {
                sessionUser = data.user; // Update data session baru
                renderProfile();
                editPopup.classList.remove("active");
                alert("Data berhasil diperbarui!");
            } else {
                editError.style.display = "block";
                editError.textContent = data.message;
            }
        } catch (err) {
            editError.style.display = "block";
            editError.textContent = "Terjadi kegagalan sistem web.";
        }
    });
});
